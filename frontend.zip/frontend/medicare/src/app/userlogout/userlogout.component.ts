import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userlogout',
  templateUrl: './userlogout.component.html',
  styleUrls: ['./userlogout.component.css']
})
export class UserlogoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
