export class Medicines
{
    mid:number;
    mname:String;
    mprice:number;
    mdesc:String;
    mcategory:String;
    expiredate:String;
    mcontrol:number;
}