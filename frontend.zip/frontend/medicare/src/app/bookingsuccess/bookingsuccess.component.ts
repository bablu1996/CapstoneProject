import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingsuccess',
  templateUrl: './bookingsuccess.component.html',
  styleUrls: ['./bookingsuccess.component.css']
})
export class BookingsuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
