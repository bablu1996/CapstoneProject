export class User
{
    uid:number;
    uname:String;
    uage:number;
    uemail:String;
    upassword:String;
}