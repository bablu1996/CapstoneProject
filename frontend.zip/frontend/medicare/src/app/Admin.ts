export class Admin
{
    aid:number;
    aname:string;
    aemail:string;
    apassword:string;
}